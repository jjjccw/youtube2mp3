Simple Python script for converting YouTube URL's to mp3 files.
